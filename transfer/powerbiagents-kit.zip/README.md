# Power BI Agents — Delivery Kit

End-to-end Power BI delivery workflow for Cursor: **six specialist agents + one orchestrator**, plus a browser **Delivery Studio** (live chat, upload, download).

Repo: [vikaspbi/powerbiagents](https://github.com/vikaspbi/powerbiagents)

## Quick start (non-technical)

1. Open this repo in **Cursor**
2. Open **Delivery Studio** in the browser: [`studio/index.html`](studio/index.html)  
   (After GitHub Pages is enabled: `https://vikaspbi.github.io/powerbiagents/studio/`)
3. Click **New project** → chat, upload files, download outputs
4. Use **Copy prompt for Cursor** when you want the live AI to work a stage

## Quick start (Cursor agents)

```bash
./scripts/new-pbi-project.sh my-report
```

Then in Cursor Agent chat:

```text
/pbi-delivery
```

Or: `Create project my-report and start stage 1.`

## What’s inside

| Piece | Path |
|-------|------|
| Orchestrator skill | `.cursor/skills/pbi-delivery/` |
| Stages 1–6 agents | `.cursor/agents/pbi-*.md` |
| Shared rules | `.cursor/rules/pbi-delivery-kit.mdc` |
| Project template | `projects/_template/` |
| Delivery Studio UI | `studio/` |
| Docs | `docs/pbi-delivery-kit/` |

## Stages

1. Requirements & Proposal  
2. Architecture & Wireframes  
3. Data Feasibility  
4. Build Guidance  
5. QA / Validation  
6. Documentation  

## Notes

- Prefer **Power BI Project (`.pbip`)** under `projects/<name>/report/` for Cursor file edits  
- Studio has **no** separate Gemini API — Cursor is the AI  
- Jump to any stage if you already have upstream handoff JSON  

More detail: [docs/pbi-delivery-kit/README.md](docs/pbi-delivery-kit/README.md)
